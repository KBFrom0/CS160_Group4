# AI Usage Declaration – Group04 – Week 01
We don't use AI.
